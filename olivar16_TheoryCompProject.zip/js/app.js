var app = angular.module("WebApp", ['ngMaterial']).config(function($mdThemingProvider) {
  $mdThemingProvider.theme('default')
});